@echo off
echo %GREETING%
if not "%~1"=="" echo args: %*
